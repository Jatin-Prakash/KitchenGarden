
  # Vegetable Selling App Design

  This is a code bundle for Vegetable Selling App Design. The original project is available at https://www.figma.com/design/QnxbGivE9rqmi3o41A5tNE/Vegetable-Selling-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  